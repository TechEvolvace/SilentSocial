//  Project: SilentSocial
//  Names: Phuc Dinh, Nicholas Ng, Preston Tu, Rui Xue
//  Course: CS329E
//  Global.swift
//  SilentSocial
//
//  Created by Nicholas Gia-Bao Ng on 10/14/25.
//
// INCLUDE ANY GLOBAL VARIABLES HERE WITH COMMENT DESCRIPTIONS
