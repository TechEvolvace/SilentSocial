//  Project: SilentSocial
//  Names: Phuc Dinh, Nicholas Ng, Preston Tu, Rui Xue
//  Course: CS329E
//  Global.swift
//
// INCLUDE ANY GLOBAL VARIABLES HERE WITH COMMENT DESCRIPTIONS
